import math
import numpy as np
import pandas as pd
### giris degerleri
inputvalue = []
class1 = []
class2 = []
class3 = []
center1 = [5.5,2.6,4.4,1.2]
center2 = [5.8,2.7,5.1,1.9]
center3 = [7.2,3.2,6.0,1.8]
iteration = 100

### verilerin kume merkezlerine olan uzakliklarinin hesaplandigi fonksiyon
def distance(centersw,centersl,centerpw,centerpl,value1,value2,value3,value4):
    return math.sqrt((centersw-value1)**2 + (centersl-value2)**2 + (centerpw-value3)**2 + (centerpl-value4)**2)

### verilerin merkezlere olan uzakliklarina gore kumelere ayrildigi fonksiyon
def clustering(center1,center2,center3,value1,value2,value3,value4):
        wclass1 = distance(center1[0],center1[1],center1[2],center1[3],value1,value2,value3,value4)
        wclass2 = distance(center2[0],center2[1],center2[2],center2[3],value1,value2,value3,value4)
        wclass3 = distance(center3[0],center3[1],center3[2],center3[3],value1,value2,value3,value4)
        value = [value1,value2,value3,value4]

        if wclass1 < wclass2 and wclass1 < wclass3 :
            class1.append(value)
        elif wclass2 < wclass1 and wclass2 < wclass3 :
            class2.append(value)
        elif wclass3 < wclass2 and wclass3 < wclass1 :
            class3.append(value)

### olusturulan yeni kumelerdeki verilere gore yeni merkezlerin bulundugu fonksiyon
def new_center(classvalue):
    x = 0.0
    y = 0.0
    z = 0.0
    t = 0.0
    for i in range(len(classvalue)):
        x += classvalue[i][0]
        y += classvalue[i][1]
        z += classvalue[i][2]
        t += classvalue[i][3]
    return  [x/len(classvalue),y/len(classvalue),z/len(classvalue),t/len(classvalue)]

### iris_data dosyasindan verilerin okundugu kod parcasi
with open('iris_data.txt') as openfile:
    for line in openfile:
        inputvalue.append(line.split(","))

### dosyadaki verilerden kullanilacak olanlarin inputvalue listesine yazildigi kod parcasi
for i in range(len(inputvalue)):
    for j in range(len(inputvalue[i])):
        if j == 0 or j % 4 != 0 :
            inputvalue[i][j] = float(inputvalue[i][j])
        else:
            continue

### merkezler yedeklenir, daha sonra kumeleme fonksiyonuyla yeni merkezler hesaplanir.
for i in range(iteration):
    backup_center1 = center1
    backup_center2 = center2
    backup_center3 = center3
    for i in range(len(inputvalue)):
        clustering(center1,center2,center3, inputvalue[i][0],inputvalue[i][1],inputvalue[i][2],inputvalue[i][3])
    center1 = new_center(class1)
    center2 = new_center(class2)
    center3 = new_center(class3)

### Verilen veri setindeki kumelerin gercekten ayni verilerden olusup olusmadigini kontrol eden kod parcasi
    i1 = 0
    i2 = 0
    i3 = 0
    for i in range(3):
        count1 = 0
        count2 = 0
        count3 = 0
        for j in range(i*50,(i+1)*50):
            if i1 < len(class1) and class1[i1]==inputvalue[j]:
                count1+=1
                i1 += 1
            elif i2 < len(class2) and class2[i2]==inputvalue[j]:
                count2+=1
                i2 += 1
            elif i3 < len(class3) and class3[i3]==inputvalue[j]:
                count3+=1
                i3 += 1
        print count1,count2,count3,j

### yeni kumeler ve merkezler yazdirilir daha sonra kumeler tekrar bosaltilir
    print "****************"
    print len(class1),len(class2),len(class3)
    center1 = new_center(class1)
    center2 = new_center(class2)
    center3 = new_center(class3)
    print center1
    print center2
    print center3
    class1 = []
    class2 = []
    class3 = []

### yedeklenen merkez koordinatlari ile yeni merkez koordinatlari ayni olana kadar bu dongu devam eder.
    if backup_center1[0]-center1[0]==0 and backup_center1[1]-center1[1]==0 and \
       backup_center2[0]-center2[0]==0 and backup_center2[1]-center2[1]==0 and \
       backup_center3[0]-center3[0]==0 and backup_center3[1]-center3[1]==0:
       break
    else:
        continue